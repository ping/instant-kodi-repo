# plugin.video.itsapixelthing

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/57b7bcad73f541479cdaf66e6d7c0d2c)](https://www.codacy.com/app/92enen/plugin.video.itsapixelthing?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=enen92/plugin.video.itsapixelthing&amp;utm_campaign=Badge_Grade)

![logo](https://github.com/enen92/plugin.video.itsapixelthing/raw/master/resources/images/icon.png)

It's a Pixel THING kodi addon. It's a Pixel THING brings back to life those awesome gems of the golden age of video games with a personal high-quality documentary style of reviews. The industry behind the evolution of gaming, the mighty home computers from the 80s, the rise of video game consoles, all this will be featured in this weekly YouTube show!

### Screenshots

![screen1](https://github.com/enen92/plugin.video.itsapixelthing/raw/master/resources/images/screenshot-1.png)

![screen2](https://github.com/enen92/plugin.video.itsapixelthing/raw/master/resources/images/screenshot-2.png)

![screen3](https://github.com/enen92/plugin.video.itsapixelthing/raw/master/resources/images/screenshot-3.png)

![screen4](https://github.com/enen92/plugin.video.itsapixelthing/raw/master/resources/images/screenshot-4.png)

